document.getElementById('themeSwitcher').addEventListener('click', () => {
  document.body.classList.toggle('dark-mode');
});
