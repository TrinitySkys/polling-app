require('dotenv').config();
const express = require('express');
const session = require('express-session');
const cookieParser = require('cookie-parser');
const path = require('path');
const { sequelize } = require('./config/database');

const SequelizeStore = require('connect-session-sequelize')(session.Store);

const authRoutes = require('./routes/authRoutes');
const pollRoutes = require('./routes/pollRoutes');

const app = express();

// Set up session store using MySQL
const sessionStore = new SequelizeStore({
  db: sequelize,
  tableName: 'sessions'
});

app.use(session({
  secret: process.env.SESSION_SECRET || 'defaultsecret',
  store: sessionStore,
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: process.env.NODE_ENV === 'production', // Enable secure cookies in production
    maxAge: 1000 * 60 * 60 * 24 * 7 // 7 days
  }
}));

// Set view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());

// Fix static file path (CSS, JS, images)
app.use(express.static(path.join(__dirname, 'public')));

// Register routes with `/polling-app`
app.use('/polling-app', authRoutes);
app.use('/polling-app/polls', pollRoutes);

// Ensure root redirects correctly
app.get('/', (req, res) => {
  res.redirect('/polling-app');
});

// 404 Error Handler
app.use((req, res) => {
  res.status(404).send("404 - Page Not Found");
});

// Sync Database & Start Server
sequelize.sync().then(() => {
  console.log('✅ Database connected successfully');
  return sessionStore.sync();
}).then(() => {
  const PORT = process.env.PORT || 3000;
  app.listen(PORT, () => console.log(`🚀 Server running at: https://power2we.com/polling-app`));
}).catch((error) => {
  console.error('❌ Database connection failed:', error);
});

// Export app for debugging
module.exports = app;